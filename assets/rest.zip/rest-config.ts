import { RestClient } from './rest-lib';

const isDev = !!window.location.hostname.match(/^(localhost|127\.|192\.)/);

const endpoint = isDev ? 'http://localhost:8000' : 'https://api.prodserver.com';

const rest = new RestClient(endpoint, isDev);

export { isDev, endpoint, rest };

