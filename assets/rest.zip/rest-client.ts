import { RestClient } from './rest-lib';

export const endpoint = '';
export const rest = new RestClient(endpoint);
